package usecase

import (
	"log"
	"skillboxDiplom/internal/entity"
	"strings"
)

//func CheckSMSvalid(data SMSData) bool {
//
//	if assert.Alpha2Map[data.Country] == "" {
//		return false
//	} else if !assert.CheckValueInArray(data.Provider, assert.Providers[:]) {
//		return false
//	}
//	return true

//}

func GetSMSDataSlice(path string) ([]entity.SMSData, error) {
	rows, err := GetFileContent(path)
	if err != nil {
		log.Println(err)
		return nil, err
	}

	var result []entity.SMSData
	for _, row := range rows {
		params := strings.Split(row, ";")
		if len(params) != 4 {
			continue
		}
		sms := entity.SMSData{
			Country:      params[0],
			Bandwith:     params[1],
			ResponseTime: params[2],
			Provider:     params[3],
		}

		//if !CheckSMSvalid(sms) {
		//	continue
		//}
		//
		result = append(result, sms)
	}
	return result, nil
}
